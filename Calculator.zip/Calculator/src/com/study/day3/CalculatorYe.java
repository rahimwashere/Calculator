package com.study.day3;

import java.util.Scanner;

public class CalculatorYe {
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
	System.out.println("Give me the 1st number");

	int x = sc.nextInt();
	
	System.out.println("Now give me a 2nd number");
	
	int y = sc.nextInt();
	
	int z = x+y;
	
	System.out.println("Here's the total: "+z);
	
	int a = x*y;
	
	System.out.println("Here's the two multiplied: "+a);
	
	int b = x-y;
	
	System.out.println("And the total if they were subtracted from one another: "+b);
		
		
		
		
		
		
	}
	
	
	
	
	
	
	

}
